def test_basic_arithmetic():
    """A very simple placeholder test to ensure the CI pipeline runs."""
    assert 1 + 1 == 2