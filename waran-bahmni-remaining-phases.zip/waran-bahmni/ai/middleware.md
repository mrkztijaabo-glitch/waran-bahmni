# AI Middleware and Workflows

This document introduces the AI middleware responsible for integrating intelligent features into the Waran Bahmni HIS. It outlines sample workflows for diagnosis support, lab result analysis, and prescription recommendations, along with guidance on summarisation, caching and audit logging.

## Overview

The AI layer acts as an intermediary between the clinical modules (OpenMRS, OpenELIS and Odoo) and external AI services. It sends structured data from the HIS to models and returns concise recommendations to clinicians. Running AI functions outside of the core EMR keeps the base system stable while enabling rapid innovation.

## Diagnosis Workflow

1. A clinician creates or updates an encounter in OpenMRS.
2. The middleware collects relevant patient history, symptoms and observations via the OpenMRS API.
3. This data is sent to an AI model (e.g. an OpenAI function or locally‑hosted model) to suggest differential diagnoses.
4. Suggested diagnoses are returned with a confidence score. The clinician reviews and optionally accepts recommendations. Accepted suggestions are stored as encounter diagnoses.

## Laboratory Workflow

1. When lab results are recorded in OpenELIS, a webhook notifies the AI middleware.
2. The middleware retrieves the results and patient context.
3. An AI function interprets abnormal values and suggests follow‑up tests or notes for the clinician.
4. Suggestions are appended to the lab result record and visible in the clinician's dashboard.

## Prescription Workflow

1. During or after a diagnosis, a clinician opens the prescribing form.
2. The middleware recommends medications and dosages based on the diagnosis, allergies, and drug interactions using up‑to‑date medical knowledge.
3. Clinicians review the recommendations, adjust as needed and finalise the prescription in Odoo.

## Summarisation and Caching

AI models can summarise long patient histories or encounter notes to assist clinicians. To avoid unnecessary costs and latency, cache summaries keyed by patient ID and last updated timestamp. Invalidate the cache when new observations or encounters are recorded. Example pseudocode:

```python
def get_patient_summary(patient_id: str) -> str:
    cached = cache.get(patient_id)
    if cached and cached['updated_at'] == get_last_update(patient_id):
        return cached['summary']
    text = collect_notes(patient_id)
    summary = call_ai_model(text)
    cache.set(patient_id, {
        'summary': summary,
        'updated_at': get_last_update(patient_id)
    })
    return summary
```

## Audit Logging

All AI interactions must be logged for transparency and clinical safety. Each request and response should record:

- Timestamp
- User initiating the request
- Patient or resource identifiers
- Input data (anonymised if possible)
- AI model used and version
- Returned suggestions and confidence scores
- Whether the clinician accepted or rejected the suggestion

Audit logs can be stored in a secure append‑only database or forwarded to an observability service. Regularly review logs to detect bias or incorrect suggestions.