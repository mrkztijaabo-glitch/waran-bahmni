# n8n Agent Automation

n8n is an open‑source workflow automation tool that enables you to orchestrate tasks across services without writing bespoke integration code. Within the Waran Bahmni HIS, n8n can automate operational tasks such as sending appointment reminders, handling pull request events and redeploying services after changes are merged.

## Deploying n8n

The `docker-compose.yml` file defines a `n8n` service using the official `n8nio/n8n` image. When you bring up the stack with `docker compose up -d`, n8n will be available on port `5678` by default. Data is persisted in the `n8n_data` volume defined in the compose file.

To enable authentication or additional configuration, copy `.env.example` to `.env` and set relevant N8N_* variables (e.g. enabling basic auth or defining a credential secret).

## Workflows

Sample workflows are provided in the `n8n/workflows/` directory:

- **appointment_reminder.json** – Runs each morning at 08:00 (server time). It fetches that day's appointments from the OpenMRS API and iterates through each appointment to send a reminder via WhatsApp or email. Extend the function node to integrate with your chosen messaging provider.
- **pr_automation.json** – Listens for GitHub pull request events on this repository. It runs automated checks (linting, tests, etc.) and can merge the pull request via the GitHub API when conditions are met.
- **auto_redeploy.json** – Triggers on pushes to the `main` or `production` branches. It calls an internal deployment endpoint to redeploy the Bahmni services. Adjust the URL and payload to match your deployment environment.

To import these workflows into n8n:

1. Start the stack (`docker compose up -d`).
2. Browse to `http://localhost:5678` and log in (if authentication is enabled).
3. Open the **Workflows** tab and choose **Import from file**. Select one of the JSON files from `n8n/workflows/`.
4. Activate the workflow and monitor its executions.

You can modify or extend these sample workflows to suit your automation needs. For example, integrate the WhatsApp templates provided in the `whatsapp/templates` directory or create additional triggers for database backups and report generation.