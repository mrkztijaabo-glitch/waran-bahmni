# Role‑Based Access Control

This document describes example roles and permissions for the Waran Bahmni HIS. Role‑based access control (RBAC) ensures that users only see and do what their job requires, improving security and reducing errors.

## Roles

| Role | Description | Key Permissions |
|-----|-------------|-----------------|
| **Admin** | Oversees system configuration and maintenance. | Manage users, view and modify all records, configure system settings, manage billing and inventory. |
| **Clinician** | Doctors, nurses and other medical staff providing care. | View patient records, create encounters, order labs, prescribe medications. |
| **Lab Technician** | Laboratory personnel responsible for conducting tests. | View lab orders, update lab results. |
| **Billing Officer** | Staff handling billing and financial transactions. | View billing records, create invoices, update payment status. |
| **Pharmacist** | Dispenses medications and manages pharmacy inventory. | View prescriptions, dispense medications. |

The detailed JSON representation of these roles can be found in `roles/roles.json`.