# Reporting and Analytics

Healthcare operations benefit from clear visibility into clinical activity and financial performance. The Waran Bahmni HIS supports reporting and analytics through exported data and custom dashboards.

## Dashboards

The `analytics/dashboard.json` file provides an example of a simple dashboard. It defines several widgets (metrics) including:

- **Total Patients** – A count of unique patients registered.
- **Total Encounters** – The cumulative number of encounters recorded.
- **Lab Tests Today** – The count of lab tests performed on the current day.
- **Monthly Revenue** – The sum of billing amounts collected in the current month.

Use a dashboarding tool (e.g. Metabase, Superset or Grafana) to ingest these metrics from the system’s databases and display trends over time. You can extend the dashboard with additional charts such as encounter types, top diagnoses, lab turnaround times and inventory levels.

## Data Extraction

Data for analytics can be extracted from the underlying MySQL and PostgreSQL databases. Create read‑only database users for your analytics service and restrict access to sensitive fields. Regularly refresh your dashboards to provide up‑to‑date information to administrators and clinicians.

## Privacy Considerations

Ensure that patient‑identifiable data is anonymised or removed before sharing reports externally. Adhere to regional privacy laws and hospital policies regarding data retention and disclosure.