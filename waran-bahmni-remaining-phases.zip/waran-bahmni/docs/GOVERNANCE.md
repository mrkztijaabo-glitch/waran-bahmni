# Governance

This document outlines the governance model for the Waran Bahmni HIS project. Clear governance promotes a healthy community, transparent decision‑making and sustainable development.

## Roles and Responsibilities

- **Maintainers** – Responsible for reviewing and merging contributions, releasing new versions and ensuring adherence to project standards. Maintainers have write access to the repository and oversee the roadmap.
- **Contributors** – Anyone who submits issues, pull requests or documentation improvements. Contributors follow the contribution guidelines and participate in discussions.
- **Users** – Healthcare institutions and individuals deploying the software. Users are encouraged to report bugs and suggest enhancements.

## Decision‑Making

Decisions about features, architecture and roadmap changes are made through consensus among maintainers, taking into account community feedback. Significant changes should be proposed via GitHub pull requests or discussions and remain open for community review before merging.

## Code of Conduct

All participants are expected to follow a Code of Conduct that fosters a welcoming and inclusive environment. Harassment and discriminatory behaviour are not tolerated. Violations may result in removal from the community.

## Branching Strategy

- The **main** branch holds stable code ready for production.
- The **staging** branch is used for testing and integration of new features. Pull requests should target this branch by default.
- The **production** branch contains the code currently deployed in production environments. Only maintainers can merge into this branch after successful testing.

## Release Process

1. Features and fixes are merged into `staging` via pull requests.
2. When `staging` is stable and passes CI, it is merged into `main`.
3. Maintainers tag a new release on `main` and update `production` accordingly.

## Security Reporting

Security vulnerabilities should be reported privately to the maintainers. Please do not disclose security issues publicly until a fix has been released.