# Training and Onboarding

Proper training ensures that clinical and administrative staff can use the Waran Bahmni HIS effectively and safely. This document provides guidance on structuring training programmes and developing user competence.

## Training Phases

1. **Introduction** – Provide an overview of the HIS components (OpenMRS, OpenELIS, Odoo, AI features, n8n automation and WhatsApp integration). Explain the benefits and workflows supported by the system.
2. **Role‑Specific Instruction** – Tailor sessions for different user groups:
   - Clinicians: patient registration, encounters, ordering labs, reviewing results, prescribing medications.
   - Lab technicians: receiving orders, entering results, using AI recommendations.
   - Billing officers: generating invoices, updating payment status, running financial reports.
   - Administrators: user management, system configuration, backups and governance.
3. **Hands‑On Practice** – Use a training environment or sandbox with dummy data. Encourage users to practice typical scenarios without affecting production data.
4. **Assessment** – Validate competency through quizzes or observed workflows. Provide additional support where needed.
5. **Continuous Learning** – Offer refresher courses when new features are introduced (e.g. AI updates, new n8n workflows, or changes in regulations).

## Training Materials

- **User Guides** – Step‑by‑step instructions with screenshots and expected outcomes.
- **Videos** – Short video demonstrations for common tasks.
- **FAQs** – A curated list of frequently asked questions and troubleshooting tips.
- **Reference Cards** – Quick‑reference sheets summarising key workflows and shortcuts.

## Feedback and Improvement

Collect feedback after training sessions to identify areas for improvement. Encourage users to report usability issues and propose enhancements through the project’s issue tracker.