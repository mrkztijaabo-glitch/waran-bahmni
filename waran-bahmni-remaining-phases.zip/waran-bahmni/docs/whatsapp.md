# WhatsApp Integration

The Waran Bahmni HIS can send notifications to patients via WhatsApp using pre‑approved message templates. This integration relies on the WhatsApp Business API (e.g. through a provider like Twilio or Meta) and can be orchestrated using n8n.

## Templates

Templates are stored as JSON files in the `whatsapp/templates/` directory. Each template includes a name, language and message components with numbered placeholders (e.g. `{{1}}`, `{{2}}`) that are replaced at runtime.

- **appointment_reminder.json** – Reminds a patient of an upcoming appointment. Placeholders: patient name, date, time.
- **lab_result.json** – Notifies a patient that their lab results are available. Placeholders: patient name, test name.
- **billing_notification.json** – Informs a patient of their billing amount and due date. Placeholders: patient name, amount, due date.

Feel free to create additional templates for follow‑up visits, medication reminders or health promotion campaigns. When adding new templates, ensure they follow the provider’s guidelines and submit them for approval if necessary.

## Sending Messages

Messages can be sent programmatically from n8n workflows or from other backend services. A typical flow is:

1. Retrieve the appropriate template and substitute the numbered placeholders with real values (e.g. patient name, appointment date).
2. Send a request to your WhatsApp API provider specifying the template name, language and parameters.
3. Handle delivery receipts and errors according to the provider’s API.

Integrate WhatsApp messaging into clinical workflows (e.g. appointment reminders) to improve patient engagement and reduce no‑shows.